package com.example.VarianTech;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VarianTechApplication {

	public static void main(String[] args) {
		SpringApplication.run(VarianTechApplication.class, args);
	}

}
