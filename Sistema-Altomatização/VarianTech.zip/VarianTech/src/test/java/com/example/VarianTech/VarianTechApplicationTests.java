package com.example.VarianTech;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VarianTechApplicationTests {

	@Test
	void contextLoads() {
	}

}
